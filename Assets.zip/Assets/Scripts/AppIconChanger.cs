using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;

public class AppIconChanger : MonoBehaviour
{
    public string newIconName;
    
    private Button button;

    private void Start()
    {
        button = GetComponent<Button>();
        button.onClick.AddListener(ChangeIcon);
    }

    private void OnDestroy()
    {
        button.onClick.RemoveListener(ChangeIcon);
    }

    private void ChangeIcon()
    {
        Debug.Log($"ChangeIcon {button.gameObject.name}");
        
        string manifestPath = Application.dataPath + "/Plugins/Android/AndroidManifest.xml";
        string manifestContent = File.ReadAllText(manifestPath);

        // Используем регулярное выражение для замены
        string pattern = @"android:icon=""@drawable/[^""]+""";
        string replacement = "android:icon=\"@drawable/" + newIconName + "\"";
        manifestContent = Regex.Replace(manifestContent, pattern, replacement);

        File.WriteAllText(manifestPath, manifestContent);
        
    }
}
