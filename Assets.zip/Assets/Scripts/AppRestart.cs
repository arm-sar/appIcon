using UnityEngine;
using UnityEngine.UI;

public class AppRestart : MonoBehaviour
{
    private Button button;

    private void Start()
    {
        button = GetComponent<Button>();
        button.onClick.AddListener(Restart);
    }

    private void OnDestroy()
    {
        button.onClick.RemoveListener(Restart);
    }

    private void Restart()
    {
        Application.Quit();
    }
}
