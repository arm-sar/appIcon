﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class ChangeAppIcon : MonoBehaviour
{
    public string IconName;
    // Вызывается при запуске приложения
    private void Start()
    {
        // Получаем компонент Button
        var button = GetComponent<Button>();

        // Подписываемся на событие нажатия на кнопку
        button.onClick.AddListener(OnClick);
    }

    private void OnDestroy()
    {
        // Отписываемся от события нажатия на кнопку
        GetComponent<Button>()?.onClick?.RemoveListener(OnClick);
    }

    void OnClick()
    {
        // Изменяем иконку приложения
        ChangeIcon(IconName);
    }

    // Функция для изменения иконки приложения
    void ChangeIcon(string iconName)
    {
        string packageName = "com.CodXplorer.AppIconChanger";

        // Получаем текущий контекст (Activity)
        AndroidJavaObject currentActivity = new AndroidJavaClass("com.unity3d.player.UnityPlayer")
            .GetStatic<AndroidJavaObject>("currentActivity");

        // Получаем PackageManager
        AndroidJavaObject packageManager = currentActivity.Call<AndroidJavaObject>("getPackageManager");

        // Получаем ComponentName текущего компонента
        AndroidJavaObject componentName = new AndroidJavaObject("android.content.ComponentName", packageName, currentActivity.Call<string>("getComponentName"));

        // Получаем ресурс иконки по имени
        int iconId = packageManager.Call<int>("getIdentifier", iconName, "drawable", packageName);

        // Устанавливаем новую иконку
        packageManager.Call("setComponentEnabledSetting", componentName, 1, 1);
        currentActivity.Call("setTheme", iconId);

        Debug.Log("Иконка изменена на " + iconName);
    }

}
